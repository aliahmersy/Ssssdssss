# Created By @xl444
# Copyright By watan

from os import getenv

from dotenv import load_dotenv

load_dotenv()

que = {}
admins = {}
SESSION_NAME = getenv("SESSION_NAME", "BAB70I9bwA6g0NCWID3a_DefS11D4z8zo4CKkjq43ZKOLuUOeAgN6jIQvIygoCyqiqqF-gYuIoguooJB1SHyi27az1BxgQQooXUFDoh6jPKcZpIJlXvJ6NQp-lWCnMRy7iaZvZAnFr7KJ-n9ozY4BffbDW-qnbVRsHz8Io9tCmk5mm8-ueNzmr8Jk4yjYGm15AXHSLAims_tlULo_yWBFczMIzfoGv8ZydGar2qm2Sqd5V36nwdsM56GufFNH82UcOsbXejze3w6uexo1GDL-rZpuNnkaRLqAc6hZeh1Y_f-Qv5Kdhquy-qeHcNoXYRtuHHGkxTEh_YN_BpM7yEhIdP7AAAAAWIm-aQA")
BOT_TOKEN = getenv("BOT_TOKEN", "6170657330:AAHHOpghxQf1vcCYiuHLWAkWROCVSQEG3ic")
BOT_NAME = getenv("BOT_NAME", "bot")
BOT_USERNAME = getenv("BOT_USERNAME", "BDAYAT6BOT")
ASSID = int(getenv("ASSID", "29035333"))
ASSNAME = getenv("ASSNAME", "Kasijekg")
ASSUSERNAME = getenv("ASSUSERNAME", "Kasijekg")

BOT_ID = int(getenv("BOT_ID", "29035333"))
UPSTREAM_REPO = getenv("UPSTREAM_REPO", "https://github.com/STKR2/LG")
UPSTREAM_BRANCH = getenv("UPSTREAM_BRANCH", "main")
HEROKU_API_KEY = getenv("HEROKU_API_KEY")
HEROKU_APP_NAME = getenv("HEROKU_APP_NAME")
MONGO_DB_URI = getenv("MONGO_DB_URI", "mongodb+srv://veez:mega@cluster0.heqnd.mongodb.net/veez?retryWrites=true&w=majority")
API_ID = int(getenv("API_ID", "29035333"))
API_HASH = getenv("API_HASH", "85d2357d1e0e5b3399aaa3c7bf01dd4f")
OWNER_ID = int(getenv("OWNER_ID", "29035333"))
UPDATE = getenv("UPDATE", "ibnsHaRaWi")
SUPPORT = getenv("SUPPORT", "ibnsHaRaWi")
DURATION_LIMIT = int(getenv("DURATION_LIMIT", "999"))
CMD_MUSIC = list(getenv("CMD_MUSIC", ". / ! + - @ # $").split())
BG_IMG = getenv("BG_IMG", "https://te.legra.ph/file/466de30ee0f9383c8e09e.jpg")
SUDO_USERS = list(map(int, getenv("SUDO_USERS", "1854384004").split()))
START_PIC = getenv("START_PIC", "https://graph.org/file/8882cbd7cc786826d9ecb.jpg")
OWNER_USERNAME = getenv("OWNER_USERNAME", "rr8r9")
IMG_1 = getenv("IMG_1", "https://graph.org/file/475127193de2444183fd4.jpg")
IMG_2 = getenv("IMG_2", "https://graph.org/file/8882cbd7cc786826d9ecb.jpg")
IMG_3 = getenv("IMG_3", "https://graph.org/file/8882cbd7cc786826d9ecb.jpg")
IMG_4 = getenv("IMG_4", "https://graph.org/file/8882cbd7cc786826d9ecb.jpg")
