import asyncio

from pyrogram import filters
from pyrogram.errors import FloodWait

from m8n import app
from m8n.config import SUDO_USERS
from m8n.utils.filters import command
from m8n.tgcalls import client as USER
from m8n.database.chats import add_served_chat, blacklisted_chats, get_served_chats

chat_watcher_group = 10


@app.on_message(group=chat_watcher_group)
async def chat_watcher_func(_, message):
    chat_id = message.chat.id
    blacklisted_chats_list = await blacklisted_chats()

    if not chat_id:
        return

    if chat_id in blacklisted_chats_list:
        try:
            await USER.leave_chat(chat_id)
        except:
            pass
        return await app.leave_chat(chat_id)

    await add_served_chat(chat_id)


@app.on_message(command("رسالة") & filters.user(SUDO_USERS))
async def broadcast_message(_, message):
    if not message.reply_to_message:
        pass
    else:
        x = message.reply_to_message.message_id
        y = message.chat.id
        sent = 0
        pin = 0
        chats = []
        schats = await get_served_chats()
        for chat in schats:
            chats.append(int(chat["chat_id"]))
        for i in chats:
            try:
                m = await app.forward_messages(i, y, x)
                try:
                    await m.pin(disable_notification=False)
                    pin += 1
                except Exception:
                    pass
                await asyncio.sleep(0.3)
                sent += 1
            except Exception:
                pass
        await message.reply_text(
            f"**- تم إذاعة الرسالة  {sent} دردشة {pin} تم تثبيت.**"
        )
        return
    if len(message.command) < 2:
        await message.reply_text("- الاستخدام : رسالة بالرد على مسج")
        return
    text = message.text.split(None, 1)[1]
    sent = 0
    pin = 0
    chats = []
    schats = await get_served_chats()
    for chat in schats:
        chats.append(int(chat["chat_id"]))
    for i in chats:
        try:
            m = await app.send_message(i, text=text)
            try:
                await m.pin(disable_notification=False)
                pin += 1
            except Exception:
                pass
            await asyncio.sleep(0.3)
            sent += 1
        except Exception:
            pass
    await message.reply_text(
        f" **- اذاعة الرسالة {sent} دردشة {pin} تم تثبيت .**"
    )


# Broadcast without pinned


@app.on_message(command("اذاعة") & filters.user(SUDO_USERS) & ~filters.edited)
async def broadcast_message(_, message):
    if len(message.command) < 2:
        return await message.reply_text("- الاستخدام اذاعة بالرد على مسج")
    sleep_time = 0.1
    text = message.text.split(None, 1)[1]
    sent = 0
    schats = await get_served_chats()
    chats = [int(chat["chat_id"]) for chat in schats]
    m = await message.reply_text(
        f"- الإذاعة قيد التنفيذ {len(chats) * sleep_time} انتظر فقط ."
    )
    for i in chats:
        try:
            await app.send_message(i, text=text)
            await asyncio.sleep(sleep_time)
            sent += 1
        except FloodWait as e:
            await asyncio.sleep(int(e.x))
        except Exception:
            pass
    await m.edit(f" **- اذاعة الرسالة {sent} كروب .**")
